# ExpensesTracker_MERN_Stack_App
In this project, we are going to learn how to make expense tracker application using Mongodb, Express, React and Node.


#### Cd into Server Folder and Start the Server First. ( make sure you install all node modules using 
```bash
pip install foobar
```)
#### Cd into Client Folder and Start the React Development Server. ( make sure you install all node modules using 
```bash
pip install foobar
```)

[Youtube Video Tutorial Link](https://youtu.be/mhM-blTHBz8)
